# Supply Chain Guardian · Phase 1

## Start the repository scanner

Open a terminal in this `guardian-phase1` folder. You need Git and Node.js 22.15+ with npm.

```bash
npm ci --ignore-scripts
npm start
```

Open [http://127.0.0.1:4173](http://127.0.0.1:4173) while the terminal is running. Paste a public GitHub repository URL and select **Analyze repository**. You can also paste a GitHub tree URL for a branch, tag, full commit SHA, or application folder. A plain repository URL uses its default branch at scan time.

Guardian lists committed folders containing `package.json` under **Application path**. A tree URL with an application folder selects that folder. Otherwise, Guardian starts with a shallow path with a committed npm lockfile when one is available. Switching the application keeps the same commit and uses the npm workspace lockfile when applicable.

The direct graph shows eight package instances per page, with package names, versions, and evidence filenames. Use **Previous** and **Next** to browse every direct package. Select a package to trace its paths, inspect the evidence, or search across the full graph. The browser address and **Copy scan URL** reopen the pinned result when the local Guardian server is running.

The scanner reads committed manifest and lockfile data. It supports npm lockfiles v2/v3 and the root-only empty v1 case. Repositories using other lock formats can still report their manifest declarations and why a resolved graph is unavailable. The scanner fetches a shallow commit and the relevant metadata without checking out or running repository code. It retains up to four recent repository sessions so switching apps does not require a fresh download. If port 4173 is occupied, run `npm start -- --port 4174` and use the URL printed in the terminal.

## Repository URLs to try

| Case | Repository snapshot | What to check |
| --- | --- | --- |
| Normal app | [Docker Todo backend](https://github.com/docker/getting-started-todo-app/tree/55680777bc46c59d3fe0ab9ff7e79ee947d0c757/backend) | Search for `debug@4.4.1` to see more than one route to the same package instance. |
| Missing lockfile | [Express](https://github.com/expressjs/express/tree/43fca52d28a422c8be48fd489cbd4f2d6152bab6) | The report contains `LOCKFILE_MISSING` and the page shows requested ranges from the manifest. |
| Zero dependencies | [npm empty-lock test fixture](https://github.com/npm/cli/tree/787f1520fa412e91a5792468f1c7f25b166867a6/workspaces/arborist/test/fixtures/empty-with-shrinkwrap) | The graph shows one application root and no edges. |
| Shared npm lockfile | [Back Office API](https://github.com/Planning-Inspectorate/back-office/tree/660507ef0db2e737cad50fb11349d8a36ff16f3f/apps/api) | Browse all 57 direct packages, then switch to `apps/web` using the application selector. Both reports share the same lockfile path and SHA-256. |

## Offline demo and CLI

Open `demo/Guardian_Phase_1_Demo.html` to inspect the bundled snapshots without starting the server. Choose an example or paste one of the pinned URLs above. The standalone HTML uses those snapshots. Live repository analysis runs through `npm start`.

```bash
npm test
npm run demo
npm run scan -- --repo ../checkout --ref HEAD --app . --out ./runs/checkout
```

`npm run demo` fetches pinned public commits into `.demo-cache` and regenerates the browser file and JSON in `demo/`. You can give it a different output directory with `npm run demo -- ./demo-rebuild`.

The scan reads metadata from the pinned Git commit. Use a repository-relative app path, such as `backend` or `apps/web`. Use a new output directory for each scan.

| Output | Meaning |
| --- | --- |
| `report.json` | Status, manifest declarations, selected commit, effective lockfile, content hashes and diagnostics |
| `graph.json` | Package instances, dependency relationships, and lockfile evidence where a graph is available |
| `repo.sbom.cdx.json` | CycloneDX 1.6 export for a resolved graph |
| `image.sbom.cdx.json` | Optional, separate artifact inventory after a successful Syft scan |

Exit 0 indicates a resolved scan. Exit 2 indicates a partial source result or an unsuccessful requested image scan. Exit 1 indicates a command or collection error. A missing lockfile produces a report and no graph. A resolved zero-dependency project produces a graph and SBOM with a root and no children.

## How the graph is built and checked

Git supplies committed manifests and lockfiles. The collector finds the owning npm workspace, loads the virtual dependency tree with Arborist, and follows resolved edges from the selected app. Node IDs use npm locations to distinguish separate instances with identical versions. Package URLs identify packages across tools. Optional unresolved edges are reported in diagnostics. The collector supports npm lockfile v2/v3 and the root-only v1 case.

Graph validation checks root reachability and edge references. SBOM validation checks structure against the vendored CycloneDX schema with Ajv and compares component IDs and dependency edges against the graph. The schemas are from [CycloneDX/specification](https://github.com/CycloneDX/specification/tree/5fee6af48d43c751dc6a5b31138f06af2b10bac5/schema). The viewer displays a limited number of paths at a time and keeps the full graph available for download.

## Optional container inventory

With Syft installed, add `--image REGISTRY/REPOSITORY@sha256:DIGEST --platform linux/amd64` to the scan. Supply an authorized immutable image reference and the correct target platform. The image is inventoried without starting a container. Image inventory is kept in a separate file. The five bundled demo views use repository evidence.
