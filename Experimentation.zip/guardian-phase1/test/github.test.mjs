import test from 'node:test';
import assert from 'node:assert/strict';
import { discoverApplications, parseRepository } from '../src/github.mjs';

test('repository URLs support clone links and tree links with encoded refs', () => {
  assert.deepEqual(parseRepository(' https://github.com/owner/repo.git/ '), {
    url: 'https://github.com/owner/repo', repo: 'owner/repo', tree: [],
  });
  assert.deepEqual(parseRepository('https://github.com/owner/repo/tree/release%2Fstable/apps/my%20app?x=1').tree,
    ['release', 'stable', 'apps', 'my app']);
  for (const url of [
    'https://github.com.evil.test/owner/repo', 'https://name@github.com/owner/repo',
    'file:///tmp/owner/repo', 'http://github.com/owner/repo', 'https://github.com/owner',
    'https://github.com/owner/repo/blob/main/package.json', 'https://github.com/owner/repo/tree/main/%5Ctmp',
  ]) {
    assert.throws(() => parseRepository(url), Error, url);
  }
});

test('app discovery prioritizes a committed npm lock then shallow manifest paths', () => {
  const entries = [
    '.', 'app', 'services/api', 'services/api/fixture', 'javascript',
  ].map(dir => [dir === '.' ? 'package.json' : dir + '/package.json']);
  entries.push(['services/api/package-lock.json'], ['javascript/yarn.lock'], ['unrelated/package-lock.json']);
  assert.deepEqual(discoverApplications(entries), ['services/api', '.', 'app', 'javascript', 'services/api/fixture']);
  assert.deepEqual(discoverApplications([...entries, ['npm-shrinkwrap.json']]), ['.', 'services/api', 'app', 'javascript', 'services/api/fixture']);
});
