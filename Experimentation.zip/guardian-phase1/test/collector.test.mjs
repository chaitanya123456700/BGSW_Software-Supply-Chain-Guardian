import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { collect } from '../src/collect.mjs';
import { git } from '../src/snapshot.mjs';
import { exportSbom, verifyRelationships } from '../src/sbom.mjs';

const app = (name, dependencies = {}) => ({ name, version: '1.0.0', dependencies });
const modern = (manifest, ...entries) => ({
  name: manifest.name,
  version: manifest.version,
  lockfileVersion: 3,
  requires: true,
  packages: { '': manifest, ...Object.assign({}, ...entries) },
});

function fixture(t, files) {
  const repo = mkdtempSync(path.join(tmpdir(), 'guardian-test-'));
  t.after(() => rmSync(repo, { recursive: true, force: true }));
  git(repo, 'init', '-q');
  for (const [file, object] of Object.entries(files)) {
    const target = path.join(repo, file);
    mkdirSync(path.dirname(target), { recursive: true });
    writeFileSync(target, JSON.stringify(object));
  }
  git(repo, 'add', '.');
  git(repo, '-c', 'user.name=Guardian', '-c', 'user.email=guardian@example.invalid', 'commit', '-qm', 'Test fixture');
  return repo;
}

test('missing lockfile yields declarations and an unavailable graph', async t => {
  const repo = fixture(t, { 'package.json': app('demo', { test: '^1.2.0' }) });
  const result = await collect({ repo });
  assert.equal(result.status, 'partial');
  assert.equal(result.graph, null);
  assert.equal(result.diagnostics[0].code, 'LOCKFILE_MISSING');
  assert.deepEqual(result.declarations, [{ name: 'test', requested: '^1.2.0', kind: 'dependencies' }]);
});

test('modern empty lockfile yields one root and a valid BOM with no dependency edges', async t => {
  const manifest = app('empty');
  const repo = fixture(t, { 'package.json': manifest, 'package-lock.json': modern(manifest) });
  const result = await collect({ repo });
  assert.equal(result.status, 'resolved');
  assert.equal(result.graph.nodes.length, 1);
  assert.deepEqual(result.graph.edges, []);
  const sbom = exportSbom(result.graph, result.source);
  assert.deepEqual(sbom.components, []);
  assert.deepEqual(sbom.dependencies, [{ ref: 'npm:.', dependsOn: [] }]);
});

test('same-version instances keep their own children and shared packages keep both parents', async t => {
  const manifest = app('demo', { a: '1.0.0', b: '1.0.0', helper: '3.0.0' });
  const lock = modern(manifest, {
    'node_modules/a': { version: '1.0.0', dependencies: { common: '1.0.0', leaf: '1.0.0', helper: '1.0.0' } },
    'node_modules/b': { version: '1.0.0', dependencies: { common: '1.0.0', leaf: '1.0.0', helper: '2.0.0' } },
    'node_modules/common': { version: '1.0.0' },
    'node_modules/a/node_modules/leaf': { version: '1.0.0', dependencies: { helper: '*' } },
    'node_modules/b/node_modules/leaf': { version: '1.0.0', dependencies: { helper: '*' } },
    'node_modules/a/node_modules/helper': { version: '1.0.0' },
    'node_modules/b/node_modules/helper': { version: '2.0.0' },
    'node_modules/helper': { version: '3.0.0' },
  });
  const repo = fixture(t, { 'package.json': manifest, 'package-lock.json': lock });
  const result = await collect({ repo });
  const sharedParents = result.graph.edges.filter(edge => edge.to === 'npm:node_modules/common').map(edge => edge.from);
  assert.deepEqual(sharedParents, ['npm:node_modules/a', 'npm:node_modules/b']);
  for (const parent of ['a', 'b']) {
    const base = 'npm:node_modules/' + parent + '/node_modules/';
    assert.ok(result.graph.edges.some(edge => edge.from === base + 'leaf' && edge.to === base + 'helper'));
  }
  assert.equal(result.graph.nodes.filter(node => node.purl === 'pkg:npm/leaf@1.0.0').length, 2);
  const sbom = exportSbom(result.graph, result.source);
  sbom.dependencies.find(row => row.ref === 'npm:node_modules/a/node_modules/leaf').dependsOn = [];
  assert.throws(() => verifyRelationships(result.graph, sbom), /differ from the graph/);
  assert.deepEqual((await collect({ repo })).graph, result.graph);
});

test('workspace views use root lock and follow local links without including sibling apps', async t => {
  const root = { ...app('workspace'), workspaces: ['apps/*', 'packages/*'] };
  const web = app('web', { ui: '1.0.0', common: '1.0.0' });
  const admin = app('admin', { charts: '1.0.0' });
  const ui = app('ui', { common: '1.0.0' });
  const lock = modern(root, {
    'apps/web': web, 'apps/admin': admin, 'packages/ui': ui,
    'node_modules/web': { link: true, resolved: 'apps/web' },
    'node_modules/admin': { link: true, resolved: 'apps/admin' },
    'node_modules/ui': { link: true, resolved: 'packages/ui' },
    'node_modules/common': { version: '1.0.0' },
    'node_modules/charts': { version: '1.0.0' },
  });
  const repo = fixture(t, {
    'package.json': root, 'package-lock.json': lock, 'apps/web/package.json': web,
    'apps/admin/package.json': admin, 'packages/ui/package.json': ui,
  });
  const left = await collect({ repo, app: 'apps/web' });
  const right = await collect({ repo, app: 'apps/admin' });
  assert.equal(left.source.lockfileSha256, right.source.lockfileSha256);
  assert.equal(left.source.lockfile, 'package-lock.json');
  assert.deepEqual(left.graph.nodes.map(node => node.name).sort(), ['common', 'ui', 'web']);
  assert.deepEqual(right.graph.nodes.map(node => node.name).sort(), ['admin', 'charts']);
  assert.equal(left.graph.edges.filter(edge => edge.to === 'npm:node_modules/common').length, 2);
});

test('workspace ownership is reported even when the root lockfile is missing', async t => {
  const root = { ...app('workspace'), workspaces: ['apps/*'] };
  const repo = fixture(t, { 'package.json': root, 'apps/web/package.json': app('web', { common: '^1.0.0' }) });
  const result = await collect({ repo, app: 'apps/web' });
  assert.equal(result.source.lockRoot, '.');
  assert.deepEqual(result.source.checkedLockPaths, ['npm-shrinkwrap.json', 'package-lock.json']);
  assert.equal(result.graph, null);
});

test('uncommitted manifest edits are ignored and foreign lockfiles are reported separately', async t => {
  const manifest = app('demo');
  const repo = fixture(t, { 'package.json': manifest, 'pnpm-lock.yaml': {} });
  writeFileSync(path.join(repo, 'package.json'), JSON.stringify(app('dirty', { test: '^1.0.0' })));
  const result = await collect({ repo });
  assert.equal(result.name, 'demo');
  assert.deepEqual(result.declarations, []);
  assert.equal(result.diagnostics[0].code, 'LOCK_FORMAT_UNSUPPORTED');
});
