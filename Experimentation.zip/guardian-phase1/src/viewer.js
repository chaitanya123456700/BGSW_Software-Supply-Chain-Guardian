'use strict';

const { mode, demos } = JSON.parse(document.getElementById('demo-data').textContent);
const live = mode === 'live';
const el = id => document.getElementById(id);
const make = (tag, text) => {
  const element = document.createElement(tag);
  if (text !== undefined) element.textContent = text;
  return element;
};
const option = (label, value) => Object.assign(make('option', label), { value });
const fileLink = (name, value) => {
  const link = make('a', name);
  link.href = URL.createObjectURL(new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' }));
  link.download = name;
  return link;
};
const pair = (list, key, value) => {
  const item = make('div');
  item.append(make('dt', key), make('dd', value));
  list.append(item);
};
const label = node => node.name + (node.version ? '@' + node.version : '');
const repoTreeUrl = ({ repo, commit, app }) => 'https://github.com/' + repo + '/tree/' + commit +
  (app === '.' ? '' : '/' + app.split('/').map(encodeURIComponent).join('/'));
let session, offlineMatches, current, nodes, outgoing, incoming, chart, urls = [];
let rootPage = 0;
const pageSize = 8;

for (const demo of demos) el('example').append(option(demo.label + ' · ' + demo.repo, repoTreeUrl(demo)));
if (!live) {
  el('mode-note').textContent = 'This offline viewer includes the example snapshots. Run npm start from the Guardian folder to analyze any supported public GitHub repository.';
}

function offlineScan(input) {
  const url = new URL(input.url);
  if (url.origin !== 'https://github.com' || url.username || url.password) {
    throw new Error('Enter a public HTTPS GitHub repository URL.');
  }
  const [owner, repo, ...rest] = url.pathname.replace(/^\/|\/$/g, '').split('/').map(decodeURIComponent);
  const slug = owner + '/' + repo?.replace(/\.git$/i, '');
  const matchingRepo = demos.filter(demo => demo.repo.toLowerCase() === slug.toLowerCase());
  const matchingCommit = matchingRepo.filter(demo => rest.length === 0 || (rest[0] === 'tree' && rest[1] === demo.commit));
  const requestedApp = input.app ?? rest.slice(2).join('/');
  const result = requestedApp ? matchingCommit.find(demo => demo.app === requestedApp) : matchingCommit[0];
  if (!result) throw new Error('This URL needs the live scanner. Run npm start from the Guardian folder and open http://127.0.0.1:4173.');
  offlineMatches = matchingCommit;
  return { apps: matchingCommit.map(demo => demo.app), result };
}

function showError(message) {
  el('scan-error').textContent = message;
  el('scan-error').hidden = !message;
}

async function analyze(input) {
  if (el('scan-button').disabled) return;
  showError('');
  el('report').hidden = true;
  el('scan-button').disabled = true;
  el('app').disabled = true;
  el('example').disabled = true;
  el('scan-status').textContent = input.url ? 'Reading the repository and analyzing its npm metadata…' : 'Analyzing ' + input.app + '…';
  el('scan-status').hidden = false;
  if (input.url) {
    el('app-field').hidden = true;
    session = undefined;
  }
  try {
    let data;
    if (live) {
      let response;
      try {
        response = await fetch('/api/scan', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input),
        });
      } catch {
        throw new Error('The local Guardian server is unreachable. Restart it with npm start and try again.');
      }
      data = await response.json();
      if (!response.ok) throw new Error(data.error);
    } else {
      data = input.url ? offlineScan(input) : {
        apps: offlineMatches.map(demo => demo.app),
        result: offlineMatches.find(demo => demo.app === input.app),
      };
    }
    const { apps, result } = data;
    session = data.session;
    const appOptions = document.createDocumentFragment();
    for (const app of apps) appOptions.append(option(app === '.' ? 'Repository root (.)' : app, app));
    el('app').replaceChildren(appOptions);
    el('app').value = result.app;
    el('app-field').hidden = false;
    if (result.error) throw new Error(result.app + ' could not be analyzed. ' + result.error);
    selectCase(result);
    if (live) {
      const permalink = new URL(location.origin);
      permalink.searchParams.set('repo', repoTreeUrl(result));
      if (result.app === '.') permalink.searchParams.set('app', '.');
      history.replaceState(null, '', permalink);
    }
  } catch (error) {
    showError(error.message);
  } finally {
    el('scan-status').hidden = true;
    el('scan-button').disabled = false;
    el('app').disabled = false;
    el('example').disabled = false;
  }
}

el('scan-form').addEventListener('submit', event => {
  event.preventDefault();
  analyze({ url: el('repo-url').value.trim() });
});
el('example').addEventListener('change', event => {
  if (!event.target.value) return;
  el('repo-url').value = event.target.value;
  el('scan-form').requestSubmit();
});
el('app').addEventListener('change', event => analyze({ session, app: event.target.value }));

function selectCase(result) {
  current = result;
  for (const link of urls) URL.revokeObjectURL(link.href);
  urls = [];
  if (chart) { chart.destroy(); chart = null; }
  const repoLink = make('a', result.repo + ' · ' + result.commit.slice(0, 8));
  repoLink.href = repoTreeUrl(result);
  repoLink.target = '_blank';
  repoLink.rel = 'noopener';
  el('repo').replaceChildren(repoLink);
  el('heading').textContent = result.name;
  const description = result.description ?? demos.find(demo =>
    demo.repo.toLowerCase() === result.repo.toLowerCase() && demo.commit === result.commit && demo.app === result.app)?.description;
  el('description').hidden = !description;
  el('description').textContent = description ?? '';

  const { graph, sbom, ...report } = result;
  urls.push(fileLink('report.json', report));
  if (graph) urls.push(fileLink('graph.json', graph));
  if (sbom) urls.push(fileLink('repo.sbom.cdx.json', sbom));
  el('downloads').replaceChildren(...urls);
  if (live && navigator.clipboard) {
    const copy = make('button', 'Copy scan URL');
    copy.type = 'button';
    copy.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(location.href);
        copy.textContent = 'Copied';
      } catch {
        copy.textContent = 'Copy the address from your browser';
      }
    });
    el('downloads').append(copy);
  }
  const facts = el('facts');
  facts.replaceChildren();
  pair(facts, 'Application path', result.app);
  pair(facts, 'Lockfile', result.source.lockfile || 'Missing');
  if (graph) {
    pair(facts, 'Package instances', String(graph.nodes.length - 1));
    pair(facts, 'Dependency edges', String(graph.edges.length));
  } else {
    pair(facts, 'Manifest declarations', String(result.declarations.length));
    pair(facts, 'Resolved graph', 'Unavailable');
  }

  renderDiagnostics(result);
  el('report').hidden = false;
  el('workspace').hidden = !graph;
  el('package-search').value = '';
  el('results').replaceChildren();
  if (!graph) return;

  nodes = new Map(graph.nodes.map(node => [node.id, node]));
  outgoing = new Map();
  incoming = new Map();
  for (const edge of graph.edges) {
    if (!outgoing.has(edge.from)) outgoing.set(edge.from, []);
    if (!incoming.has(edge.to)) incoming.set(edge.to, []);
    outgoing.get(edge.from).push(edge);
    incoming.get(edge.to).push(edge);
  }
  showRoot();
}

function renderDiagnostics(result) {
  const panel = el('diagnostics');
  const declarationSection = el('declaration-section');
  const list = el('diagnostics-list');
  const { graph, diagnostics, source } = result;
  panel.hidden = !!graph && !diagnostics.length;
  if (panel.hidden) return;
  const compact = !!graph && result.status === 'resolved';
  panel.classList.toggle('compact', compact);
  el('diagnostics-details').open = !compact;
  el('diagnostics-heading').textContent = graph
    ? 'Resolution diagnostics (' + diagnostics.length + ')'
    : 'Resolved graph unavailable';
  const first = diagnostics[0];
  el('reason').textContent = graph
    ? result.status === 'partial'
      ? 'Some declared relationships could not be resolved. The graph shows the available evidence.'
      : diagnostics.length + ' diagnostic' + (diagnostics.length === 1 ? '' : 's') + ' from lockfile analysis.'
    : first?.code === 'LOCKFILE_MISSING'
      ? 'Checked ' + source.checkedLockPaths.join(', ') + '. Exact versions and transitive paths are unknown.'
      : 'This scan could not resolve an npm dependency graph from the committed lockfile.';
  const items = make('ul');
  for (const item of diagnostics.slice(0, 50)) {
    items.append(make('li', [item.code, item.name, item.file, item.from, item.detail].filter(Boolean).join(' · ')));
  }
  if (diagnostics.length > 50) items.append(make('li', 'Download report.json for all ' + diagnostics.length + ' diagnostics.'));
  list.replaceChildren(items);
  declarationSection.hidden = !!graph || !result.declarations.length;
  const rows = document.createDocumentFragment();
  for (const entry of graph ? [] : result.declarations) {
    const row = make('tr');
    row.append(make('td', entry.name), make('td', entry.requested), make('td', entry.kind));
    rows.append(row);
  }
  el('declared').replaceChildren(rows);
}

function nodeButton(node, root = false) {
  const button = make('button');
  button.type = 'button';
  button.className = 'graph-node' + (root ? ' root-node' : '');
  const title = make('span', label(node));
  title.className = 'node-name';
  button.append(title);
  const evidence = node.evidence?.manifest || node.evidence?.file;
  if (evidence) {
    const file = make('span', evidence);
    file.className = 'node-file';
    button.append(file);
  }
  button.addEventListener('click', () => selectNode(node.id));
  return button;
}

function showRoot(resetPage = true) {
  if (resetPage) rootPage = 0;
  const root = current.graph.rootId;
  const direct = outgoing.get(root) ?? [];
  const targets = [...new Set(direct.map(edge => edge.to))];
  const shown = targets.slice(rootPage * pageSize, (rootPage + 1) * pageSize);
  const tree = el('direct-tree');
  tree.hidden = false;
  tree.classList.toggle('root-only', !shown.length);
  if (chart) { chart.destroy(); chart = null; }
  el('path-canvas').hidden = true;
  tree.replaceChildren(nodeButton(nodes.get(root), true));
  if (shown.length) {
    const branches = make('ul');
    branches.className = 'direct-list';
    for (const id of shown) {
      const branch = make('li');
      branch.append(nodeButton(nodes.get(id)));
      branches.append(branch);
    }
    tree.append(branches);
  }
  const first = rootPage * pageSize + 1;
  const last = rootPage * pageSize + shown.length;
  el('canvas-note').textContent = shown.length
    ? 'Showing ' + first + '–' + last + ' of ' + targets.length + ' direct packages · ' + direct.length + ' direct relationships'
    : 'The resolved graph contains the application root and zero dependency edges.';
  const pages = Math.ceil(targets.length / pageSize);
  el('pager').hidden = pages < 2;
  el('page').textContent = 'Page ' + (rootPage + 1) + ' of ' + pages;
  el('previous').disabled = rootPage === 0;
  el('next').disabled = rootPage + 1 >= pages;
  renderDetails(root, []);
}

function plot(ids, edges, selected) {
  const root = current.graph.rootId;
  el('direct-tree').hidden = true;
  el('pager').hidden = true;
  el('path-canvas').hidden = false;
  if (!chart) {
    chart = cytoscape({
      container: el('path-canvas'),
      style: [
        { selector: 'node', style: { 'background-color': '#1b7866', label: 'data(versionLabel)', color: '#123c34',
          'font-size': 15, 'text-valign': 'bottom', 'text-margin-y': 8, 'text-wrap': 'wrap',
          'text-overflow-wrap': 'anywhere', 'text-max-width': 170, width: 22, height: 22 } },
        { selector: '.root', style: { 'background-color': '#14372f', width: 32, height: 32 } },
        { selector: '.focus', style: { 'background-color': '#b8721e', width: 29, height: 29 } },
        { selector: 'edge', style: { width: 1.4, 'line-color': '#91ab9f', 'target-arrow-color': '#61877a',
          'target-arrow-shape': 'triangle', 'curve-style': 'bezier' } },
      ],
    });
    chart.on('tap', 'node', event => selectNode(event.target.id()));
  }
  chart.elements().remove();
  chart.add([
    ...[...ids].map(id => ({
      data: { id, versionLabel: label(nodes.get(id)) },
      classes: id === root ? 'root' : id === selected ? 'focus' : '',
    })),
    ...edges.map((edge, index) => ({ data: { id: 'edge-' + index, source: edge.from, target: edge.to } })),
  ]);
  chart.layout({ name: 'breadthfirst', directed: true, roots: chart.getElementById(root), padding: 30, spacingFactor: 1.7 }).run();
  if (chart.zoom() > 1.2) chart.zoom(1.2);
  chart.center();
}
function findPaths(target) {
  const root = current.graph.rootId;
  const distance = new Map([[target, 0]]);
  const queue = [target];
  for (let cursor = 0; cursor < queue.length; cursor += 1) {
    const node = queue[cursor];
    for (const edge of incoming.get(node) ?? []) {
      if (!distance.has(edge.from)) {
        distance.set(edge.from, distance.get(node) + 1);
        queue.push(edge.from);
      }
    }
  }

  const paths = [];
  const seenPaths = new Set();
  let budget = 5000;
  const minimum = distance.get(root);
  function visit(id, remaining, seen, edges) {
    if (--budget < 0 || paths.length === 4 || distance.get(id) > remaining) return;
    if (id === target) {
      const key = JSON.stringify(edges.map(edge => edge.to));
      if (!seenPaths.has(key)) { seenPaths.add(key); paths.push([...edges]); }
      return;
    }
    if (remaining === 0) return;
    for (const edge of outgoing.get(id) ?? []) {
      if (budget <= 0 || paths.length === 4) return;
      if (seen.has(edge.to) || !distance.has(edge.to) || distance.get(edge.to) >= remaining) continue;
      seen.add(edge.to);
      edges.push(edge);
      visit(edge.to, remaining - 1, seen, edges);
      edges.pop();
      seen.delete(edge.to);
    }
  }
  if (minimum !== undefined && minimum < 60) {
    for (let depth = minimum; depth <= minimum + 4 && paths.length < 4 && budget > 0; depth += 1) {
      visit(root, depth, new Set([root]), []);
    }
    return paths;
  }
  if (minimum === undefined) return [];
  const shortest = [];
  let node = root;
  while (node !== target) {
    const edge = (outgoing.get(node) ?? []).find(item => distance.get(item.to) === distance.get(node) - 1);
    shortest.push(edge);
    node = edge.to;
  }
  return [shortest];
}

function selectNode(id) {
  const root = current.graph.rootId;
  if (id === root) { showRoot(); return; }
  const paths = findPaths(id);
  const edges = new Map();
  const visible = new Set([root, id]);
  for (const route of paths) {
    for (const edge of route) {
      const key = JSON.stringify([edge.from, edge.to]);
      edges.set(key, edge);
      visible.add(edge.to);
    }
  }
  plot(visible, [...edges.values()], id);
  el('canvas-note').textContent = 'Showing ' + paths.length + ' path' + (paths.length === 1 ? '' : 's') +
    ' from the root. Longer alternate paths may exist.';
  renderDetails(id, paths);
}

function renderDetails(id, paths) {
  const node = nodes.get(id);
  const details = el('details');
  const title = make('strong', label(node));
  const facts = document.createElement('dl');
  if (node.purl) pair(facts, 'Package URL', node.purl);
  if (node.origin) pair(facts, 'Resolved origin', node.origin);
  if (node.evidence?.file) pair(facts, 'Lockfile evidence', node.evidence.file);
  if (node.evidence?.entry !== undefined) pair(facts, 'Lockfile entry', node.evidence.entry || '(application root)');
  if (node.evidence?.manifest) pair(facts, 'Manifest', node.evidence.manifest);
  if (id !== current.graph.rootId) {
    pair(facts, 'Declared relationship', node.development ? 'Development-only in the npm lock tree' :
      'Incoming edge types: ' + [...new Set((incoming.get(id) ?? []).map(edge => edge.kind))].join(', '));
  }
  details.replaceChildren(title, facts);
  if (paths.length) {
    const list = document.createElement('ul');
    for (const route of paths) {
      list.append(make('li', [nodes.get(current.graph.rootId), ...route.map(edge => nodes.get(edge.to))].map(label).join(' → ')));
    }
    details.append(make('h3', 'Paths from the app'), list);
  }
}

el('home').addEventListener('click', () => showRoot());
el('previous').addEventListener('click', () => { rootPage--; showRoot(false); });
el('next').addEventListener('click', () => { rootPage++; showRoot(false); });
el('package-search').addEventListener('input', event => {
  const query = event.target.value.trim().toLowerCase();
  const pane = el('results');
  pane.replaceChildren();
  if (!query) return;
  const matches = [...nodes.values()].filter(node => label(node).toLowerCase().includes(query));
  pane.append(make('p', matches.length + ' matches' + (matches.length > 16 ? ' · showing first 16' : '')));
  for (const node of matches.slice(0, 16)) {
    const result = make('button', label(node) + (node.location ? ' · ' + node.location : ''));
    result.type = 'button';
    result.addEventListener('click', () => selectNode(node.id));
    pane.append(result);
  }
});

const params = new URLSearchParams(location.search);
const initial = params.get('repo');
if (initial) {
  el('repo-url').value = initial;
  if (el('repo-url').checkValidity()) analyze({ url: initial, app: params.get('app') ?? undefined });
  else showError('Enter a valid public GitHub repository URL.');
}
