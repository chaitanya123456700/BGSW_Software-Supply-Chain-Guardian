import { parentPort, workerData } from 'node:worker_threads';
import { collect } from './collect.mjs';
import { openRepository } from './github.mjs';
import { exportSbom } from './sbom.mjs';

async function scan({ directory, target, commit, app }) {
  try {
    const result = await collect({ repo: directory, ref: commit, app, repoName: target.repo.split('/')[1] });
    const sbom = result.status === 'resolved' ? exportSbom(result.graph, result.source) : null;
    return { repo: target.repo, commit, app, ...result, sbom };
  } catch (error) {
    return { repo: target.repo, commit, app, error: error.message };
  }
}

try {
  const selection = workerData.commit ? {} : openRepository(workerData.directory, workerData.target, workerData.requestedApp);
  const result = await scan({ ...workerData, ...selection });
  parentPort.postMessage({ ...selection, result });
} catch (error) {
  parentPort.postMessage({ error: error.message });
}
