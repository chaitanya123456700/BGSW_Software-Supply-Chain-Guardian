import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { appPath, metadataEntries } from './snapshot.mjs';

export function parseRepository(input) {
  if (typeof input !== 'string' || input.length > 2048) throw new Error('Enter a public GitHub repository URL.');
  let url;
  try { url = new URL(input.trim()); } catch {}
  if (url?.origin !== 'https://github.com' || url.username || url.password) {
    throw new Error('Enter a public HTTPS GitHub URL, such as https://github.com/owner/repo.');
  }
  const [, owner, rawName, page, ...rest] = url.pathname.replace(/\/+$/, '').split('/');
  const name = rawName?.replace(/\.git$/i, '');
  if (!/^[\w-]+$/.test(owner ?? '') || !/^[\w.-]+$/.test(name ?? '') || /^\.+$/.test(name)) {
    throw new Error('The URL must include a GitHub owner and repository.');
  }
  if (page !== undefined && (page !== 'tree' || !rest.length)) {
    throw new Error('Use a repository URL or a GitHub tree URL for a branch, tag, commit, or app folder.');
  }
  let tree;
  try { tree = rest.flatMap(part => decodeURIComponent(part).split('/')); }
  catch { throw new Error('The URL contains an invalid encoded path.'); }
  if (tree.some(part => !part || part === '.' || part === '..' || /[\\\u0000-\u001f]/.test(part))) {
    throw new Error('The URL contains an invalid tree path.');
  }
  return { repo: owner + '/' + name, url: 'https://github.com/' + owner + '/' + name, tree };
}

function git(repoDir, args, input) {
  return execFileSync('git', [
    '-C', repoDir, '-c', 'protocol.allow=never', '-c', 'protocol.https.allow=always',
    '-c', 'http.followRedirects=false', '-c', 'credential.helper=', ...args,
  ], {
    encoding: 'utf8', input, maxBuffer: 64 * 1024 * 1024, timeout: 35_000,
    stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true,
    env: { ...process.env, GIT_TERMINAL_PROMPT: '0', GIT_NO_REPLACE_OBJECTS: '1' },
  }).trim();
}

function resolveTree(directory, target) {
  if (!target.tree.length) return { ref: 'HEAD' };
  if (/^[a-f0-9]{40}$/i.test(target.tree[0])) {
    return { ref: target.tree[0], app: folder(target.tree.slice(1)) };
  }

  const prefixes = target.tree.map((_, index) => target.tree.slice(0, index + 1).join('/'));
  const names = prefixes.flatMap(prefix => ['refs/heads/' + prefix, 'refs/tags/' + prefix]);
  const output = git(directory, ['ls-remote', '--refs', 'origin', ...names]);
  const refs = new Set(output.split('\n').map(line => line.split('\t')[1]));
  for (let index = prefixes.length - 1; index >= 0; index -= 1) {
    const ref = ['refs/heads/', 'refs/tags/'].map(base => base + prefixes[index]).find(name => refs.has(name));
    if (ref) return { ref, app: folder(target.tree.slice(index + 1)) };
  }
  throw new Error('GitHub could not find that branch or tag. For a commit, paste its full 40-character SHA.');
}

function folder(parts) {
  return parts.length ? appPath(parts.join('/')) : undefined;
}

export function discoverApplications(entries) {
  const paths = new Set(entries.map(([file]) => file));
  const hasLock = dir => ['npm-shrinkwrap.json', 'package-lock.json'].some(name => paths.has(path.posix.join(dir, name)));
  return [...paths]
    .filter(file => path.posix.basename(file) === 'package.json')
    .map(file => path.posix.dirname(file))
    .sort((a, b) => Number(hasLock(b)) - Number(hasLock(a)) ||
      (a === '.' ? 0 : a.split('/').length) - (b === '.' ? 0 : b.split('/').length) || a.localeCompare(b));
}

export function openRepository(directory, target, requestedApp) {
  git(directory, ['init', '--quiet', '--bare']);
  git(directory, ['remote', 'add', 'origin', target.url + '.git']);
  let selection;
  let commit;
  try {
    selection = resolveTree(directory, target);
    git(directory, ['fetch', '--quiet', '--no-tags', '--no-recurse-submodules', '--depth=1',
      '--filter=blob:none', 'origin', selection.ref]);
    commit = git(directory, ['rev-parse', '--verify', 'FETCH_HEAD^{commit}']);
  } catch (error) {
    if (error.code === 'ETIMEDOUT') throw new Error('GitHub took too long to respond. Try again in a moment.');
    if (error.status != null || error.code) {
      throw new Error('Could not fetch that GitHub repository or ref. Check that it exists and is public.');
    }
    throw error;
  }

  const entries = metadataEntries(directory, commit);
  const apps = discoverApplications(entries);
  if (!apps.length) throw new Error('This commit has no committed package.json files.');
  const app = requestedApp ?? selection.app ?? apps[0];
  if (!apps.includes(app)) {
    throw new Error('The selected app has no package.json at this commit. Use the repository or branch URL to list available apps.');
  }
  try {
    const hashes = [...new Set(entries.map(([, hash]) => hash))];
    // The shallow refs have trees but may still be missing every requested blob.
    git(directory, ['-c', 'fetch.negotiationAlgorithm=noop', 'fetch', '--quiet', '--no-tags', '--no-recurse-submodules', '--no-write-fetch-head',
      '--filter=blob:none', 'origin', '--stdin'], hashes.join('\n') + '\n');
  } catch {
    throw new Error('Could not download the committed package metadata from GitHub.');
  }
  return { commit, apps, app };
}
