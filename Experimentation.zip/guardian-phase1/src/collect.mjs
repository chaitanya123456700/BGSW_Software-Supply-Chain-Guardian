import Arborist from '@npmcli/arborist';
import mapWorkspaces from '@npmcli/map-workspaces';
import { PackageURL } from 'packageurl-js';
import { writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { appPath, extractSnapshot } from './snapshot.mjs';

const fields = ['dependencies', 'devDependencies', 'optionalDependencies', 'peerDependencies'];
const edgeOrder = (a, b) => a.from.localeCompare(b.from) || a.to.localeCompare(b.to) ||
  a.name.localeCompare(b.name) || a.kind.localeCompare(b.kind);
const nodeId = location => 'npm:' + (location || '.');
const relativeFile = (dir, file) => path.posix.join(dir, file);
const digest = bytes => createHash('sha256').update(bytes).digest('hex');

function declarations(manifest) {
  return fields.flatMap(kind => Object.entries(manifest[kind] ?? {})
    .map(([name, requested]) => ({ name, requested, kind })));
}

function getJson(files, file) {
  const bytes = files.get(file);
  if (!bytes) return null;
  try {
    const value = JSON.parse(bytes);
    if (value && typeof value === 'object' && !Array.isArray(value)) return value;
  } catch {}
  throw new Error('Invalid JSON object in ' + file);
}

async function owningRoot(snapshot, app) {
  let current = path.posix.dirname(app);
  if (app === '.') return app;
  while (true) {
    const file = relativeFile(current, 'package.json');
    const manifest = getJson(snapshot.files, file);
    if (manifest?.workspaces) {
      const owner = path.join(snapshot.directory, current);
      const members = await mapWorkspaces({ cwd: owner, pkg: manifest });
      if ([...members.values()].some(member => path.resolve(member) === path.join(snapshot.directory, app))) {
        return current;
      }
    }
    if (current === '.') return app;
    current = path.posix.dirname(current);
  }
}

function validateLockPaths(lock) {
  for (const [location, info] of Object.entries(lock.packages ?? {})) {
    if (location) appPath(location);
    if (info?.link) {
      if (typeof info.resolved !== 'string' || !info.resolved) throw new Error('Lockfile contains an invalid local link.');
      appPath(info.resolved);
    }
  }
}

function cleanReference(resolved) {
  if (!resolved) return undefined;
  try {
    const url = new URL(resolved);
    url.username = '';
    url.password = '';
    url.search = '';
    return url.href;
  } catch {
    return resolved;
  }
}

function purl(name, version) {
  if (!version || !/^(?:@[a-z0-9._~-]+\/)?[a-z0-9._~-]+$/i.test(name)) return undefined;
  const slash = name.indexOf('/');
  const namespace = slash >= 0 ? name.slice(0, slash) : undefined;
  return new PackageURL('npm', namespace, name.slice(slash + 1), version).toString();
}

function packageNode(node, lock, lockfile, isRoot, fallback, repositoryRoot) {
  const location = node.location || '';
  const entry = lock.packages?.[location];
  const name = node.package?.name || node.name || fallback;
  const version = node.package?.version || entry?.version || undefined;
  const manifest = isRoot || !location.split('/').includes('node_modules')
    ? relativeFile(relativeFile(repositoryRoot, location), 'package.json') : undefined;
  return {
    id: nodeId(location), name, version, location,
    purl: purl(name, version),
    origin: cleanReference(entry?.resolved ?? node.resolved),
    integrity: entry?.integrity ?? node.integrity ?? undefined,
    development: !!node.dev,
    optional: !!node.optional,
    peer: !!node.peer,
    evidence: { file: lockfile, entry: entry ? location : undefined, manifest },
  };
}

function sameRequests(actual, locked) {
  return fields.every(field => {
    const left = Object.entries(actual[field] ?? {}).sort();
    const right = Object.entries(locked[field] ?? {}).sort();
    return JSON.stringify(left) === JSON.stringify(right);
  });
}

function buildGraph(root, lock, info, manifest, identity) {
  const localRoot = path.posix.relative(info.lockRoot, info.app);
  const selected = localRoot ? root.inventory.get(localRoot) : root;
  if (!selected) throw new Error('Selected application is absent from the workspace lockfile.');
  const selectedNode = selected.isLink ? selected.target : selected;
  const rootId = nodeId(selectedNode.location);
  const nodes = new Map();
  const edges = [];
  const pending = [selectedNode];
  const diagnostics = [];
  const lockedRoot = lock.packages?.[selectedNode.location || ''];
  if (lockedRoot && !sameRequests(manifest, lockedRoot)) {
    diagnostics.push({ code: 'MANIFEST_LOCK_MISMATCH', severity: 'error', from: rootId });
  }

  while (pending.length) {
    const current = pending.pop();
    const id = nodeId(current.location);
    if (nodes.has(id)) continue;
    nodes.set(id, packageNode(current, lock, info.lockfile, id === rootId, identity, info.lockRoot));
    for (const edge of current.edgesOut.values()) {
      // The top-level workspace list is membership metadata. An app enters via a real dependency edge.
      if (edge.type === 'workspace') continue;
      const destination = edge.to;
      if (!destination) {
        const optional = edge.type === 'optional' || edge.type === 'peerOptional' || edge.optional;
        diagnostics.push({
          code: optional ? 'OPTIONAL_NOT_RESOLVED' : 'REQUIRED_NOT_RESOLVED',
          severity: optional ? 'info' : 'error',
          from: id, name: edge.name, requested: cleanReference(edge.spec),
        });
        continue;
      }
      const target = destination.isLink ? destination.target : destination;
      if (!target) {
        diagnostics.push({ code: 'LINK_TARGET_MISSING', severity: 'error', from: id, name: edge.name });
        continue;
      }
      edges.push({ from: id, to: nodeId(target.location), kind: edge.type, name: edge.name, requested: cleanReference(edge.spec) });
      if (!edge.valid) diagnostics.push({ code: 'RESOLUTION_CONFLICT', severity: 'warning', from: id, name: edge.name, detail: edge.error });
      if (!nodes.has(nodeId(target.location))) pending.push(target);
    }
  }

  const graph = {
    schemaVersion: 1, rootId,
    nodes: [...nodes.values()].sort((a, b) => a.id.localeCompare(b.id)),
    edges: edges.sort(edgeOrder),
  };
  validateGraph(graph);
  return { graph, diagnostics };
}

export function validateGraph(graph) {
  const ids = new Set(graph.nodes.map(node => node.id));
  if (!ids.has(graph.rootId) || ids.size !== graph.nodes.length) throw new Error('Invalid graph root or duplicate node IDs.');
  const adjacency = new Map();
  for (const edge of graph.edges) {
    if (!ids.has(edge.from) || !ids.has(edge.to)) throw new Error('Graph edge references an unknown node.');
    if (!adjacency.has(edge.from)) adjacency.set(edge.from, []);
    adjacency.get(edge.from).push(edge.to);
  }
  const seen = new Set();
  const pending = [graph.rootId];
  while (pending.length) {
    const id = pending.pop();
    if (seen.has(id)) continue;
    seen.add(id);
    for (const next of adjacency.get(id) ?? []) pending.push(next);
  }
  if (seen.size !== ids.size) throw new Error('Graph includes nodes outside the selected app.');
}

export async function collect({ repo, ref = 'HEAD', app = '.', repoName }) {
  app = appPath(app);
  const snapshot = extractSnapshot(repo, ref);
  try {
    const manifestFile = relativeFile(app, 'package.json');
    const manifest = getJson(snapshot.files, manifestFile);
    if (!manifest) throw new Error('No package.json at selected app path ' + app);
    const lockRoot = await owningRoot(snapshot, app);
    const npmLocks = ['npm-shrinkwrap.json', 'package-lock.json'].map(file => relativeFile(lockRoot, file));
    const alternative = ['pnpm-lock.yaml', 'yarn.lock', 'bun.lock', 'bun.lockb']
      .map(file => relativeFile(lockRoot, file)).find(file => snapshot.files.has(file));
    const lockfile = npmLocks.find(file => snapshot.files.has(file));
    const source = {
      commit: snapshot.commit, app, manifest: manifestFile, lockRoot,
      manifestSha256: digest(snapshot.files.get(manifestFile)),
      lockfile: lockfile ?? null, checkedLockPaths: npmLocks,
      lockfileSha256: lockfile ? digest(snapshot.files.get(lockfile)) : null,
    };
    const identity = manifest.name || (app === '.' ? repoName || path.basename(path.resolve(repo)) : path.posix.basename(app));
    const makeResult = (status, diagnostics, graph = null) => ({
      status, name: identity, source, declarations: declarations(manifest), diagnostics, graph,
    });
    if (!lockfile) {
      const diagnostic = alternative
        ? { code: 'LOCK_FORMAT_UNSUPPORTED', severity: 'error', file: alternative }
        : { code: 'LOCKFILE_MISSING', severity: 'error' };
      return makeResult('partial', [diagnostic]);
    }

    const lock = getJson(snapshot.files, lockfile);
    source.lockfileVersion = lock.lockfileVersion;
    if (lock.lockfileVersion === 1 && app === lockRoot && !manifest.workspaces &&
        declarations(manifest).length === 0 && Object.keys(lock.dependencies ?? {}).length === 0 &&
        Object.keys(lock.packages ?? {}).length === 0) {
      // npm upstream includes a committed, root-only legacy lockfile fixture.
      const node = {
        id: nodeId(''), name: identity, version: manifest.version,
        evidence: { file: lockfile, manifest: manifestFile },
      };
      return makeResult('resolved', [], { schemaVersion: 1, rootId: node.id, nodes: [node], edges: [] });
    }
    if (![2, 3].includes(lock.lockfileVersion) || !lock.packages?.['']) {
      return makeResult('partial', [{ code: 'LOCK_VERSION_UNSUPPORTED', severity: 'error' }]);
    }

    validateLockPaths(lock);
    writeFileSync(path.join(snapshot.directory, lockfile), snapshot.files.get(lockfile));
    const root = await new Arborist({ path: path.join(snapshot.directory, lockRoot), offline: true }).loadVirtual();
    const { graph, diagnostics } = buildGraph(root, lock, source, manifest, identity);
    const status = diagnostics.some(item => item.severity === 'error') ? 'partial' : 'resolved';
    return makeResult(status, diagnostics, graph);
  } finally {
    snapshot.close();
  }
}
