import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { collect } from './collect.mjs';
import { exportSbom } from './sbom.mjs';
import { renderViewer } from './render-viewer.mjs';

const project = fileURLToPath(new URL('../', import.meta.url));
const demos = JSON.parse(readFileSync(path.join(project, 'demos.json')));
const work = path.resolve(process.env.GUARDIAN_DEMO_CACHE ?? path.join(project, '.demo-cache'));
const output = path.resolve(process.argv[2] ?? path.join(project, 'demo'));
const git = (args) => execFileSync('git', args, { stdio: 'inherit', windowsHide: true });
const asJson = value => JSON.stringify(value, null, 2) + '\n';

mkdirSync(work, { recursive: true });
mkdirSync(output, { recursive: true });
const results = [];
for (const demo of demos) {
  const repo = path.join(work, demo.repo.replace('/', '__'));
  if (!existsSync(repo)) {
    mkdirSync(repo);
    git(['-C', repo, 'init', '--quiet']);
  }
  try {
    execFileSync('git', ['-C', repo, 'cat-file', '-e', demo.commit + '^{commit}'], { stdio: 'ignore' });
  } catch {
    git(['-C', repo, 'fetch', '--quiet', '--depth=1', 'https://github.com/' + demo.repo + '.git', demo.commit]);
  }
  const result = await collect({ repo, ref: demo.commit, app: demo.app });
  const sbom = result.status === 'resolved' ? exportSbom(result.graph, result.source) : null;
  const expected = demo.id === 'missing' ? 'partial' : 'resolved';
  if (result.status !== expected) throw new Error('Unexpected result for ' + demo.id + ': ' + result.status);
  if (demo.id === 'missing' && (result.graph || result.diagnostics[0]?.code !== 'LOCKFILE_MISSING')) {
    throw new Error('Missing lockfile unexpectedly yielded a graph.');
  }
  if (demo.id === 'empty' && (result.graph.nodes.length !== 1 || result.graph.edges.length !== 0)) {
    throw new Error('Root-only example unexpectedly yielded dependencies.');
  }
  const dir = path.join(output, demo.id);
  mkdirSync(dir, { recursive: true });
  const { graph, ...report } = result;
  writeFileSync(path.join(dir, 'report.json'), asJson(report));
  if (graph) writeFileSync(path.join(dir, 'graph.json'), asJson(graph));
  if (sbom) writeFileSync(path.join(dir, 'repo.sbom.cdx.json'), asJson(sbom));
  results.push({ ...demo, ...result, sbom });
  console.log(demo.id + ': ' + result.status + ' · ' + (graph ? graph.nodes.length + ' nodes, ' + graph.edges.length + ' arrows' : 'graph unavailable'));
}

const shared = results.filter(item => item.id.startsWith('shared-'));
if (shared[0].source.lockfileSha256 !== shared[1].source.lockfileSha256 ||
    JSON.stringify(shared[0].graph.nodes) === JSON.stringify(shared[1].graph.nodes)) {
  throw new Error('Shared-lockfile example did not show different graphs from the same lockfile.');
}

writeFileSync(path.join(output, 'Guardian_Phase_1_Demo.html'),
  renderViewer({ mode: 'offline', demos: results }));
