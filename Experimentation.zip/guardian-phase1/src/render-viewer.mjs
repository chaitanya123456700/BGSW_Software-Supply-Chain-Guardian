import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';

const require = createRequire(import.meta.url);
const asset = name => readFileSync(new URL(name, import.meta.url), 'utf8');
const embed = value => value.replace(/<\/script/gi, '<\\/script');

export function renderViewer({ mode, demos }) {
  const cytoscape = readFileSync(path.join(path.dirname(require.resolve('cytoscape')), 'cytoscape.min.js'), 'utf8');
  const sections = {
    STYLE: asset('viewer.css'),
    CYTOSCAPE: embed(cytoscape),
    DATA: JSON.stringify({ mode, demos }).replace(/</g, '\\u003c'),
    SCRIPT: embed(asset('viewer.js')),
  };
  return asset('viewer.html').replace(/<!-- (STYLE|CYTOSCAPE|DATA|SCRIPT) -->/g, (_, name) => sections[name]);
}
