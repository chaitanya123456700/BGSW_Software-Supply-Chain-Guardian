import { parseArgs } from 'node:util';
import { spawnSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { collect } from './collect.mjs';
import { exportSbom } from './sbom.mjs';

const json = value => JSON.stringify(value, null, 2) + '\n';
const write = (out, name, value) => writeFileSync(path.join(out, name), json(value));

async function main() {
  const { values } = parseArgs({ options: {
    repo: { type: 'string' }, ref: { type: 'string', default: 'HEAD' },
    app: { type: 'string', default: '.' }, out: { type: 'string' }, image: { type: 'string' },
    platform: { type: 'string', default: 'linux/amd64' }, help: { type: 'boolean', short: 'h' },
  } });
  if (values.help) {
    console.log('Usage: npm run scan -- --repo PATH --out NEW_DIR [--ref SHA] [--app apps/web] [--image NAME@sha256:DIGEST --platform linux/amd64]');
    return;
  }
  if (!values.repo || !values.out) throw new Error('--repo and --out are required. The output directory must be new.');
  const result = await collect(values);
  const sbom = result.status === 'resolved' ? exportSbom(result.graph, result.source) : null;
  const out = path.resolve(values.out);
  mkdirSync(path.dirname(out), { recursive: true });
  mkdirSync(out);
  if (result.graph) write(out, 'graph.json', result.graph);
  if (sbom) write(out, 'repo.sbom.cdx.json', sbom);
  const { graph, ...report } = result;
  report.summary = graph ? { nodes: graph.nodes.length, edges: graph.edges.length } : null;
  report.toolchain = { node: process.version, arborist: '9.9.1', cyclonedx: '1.6' };
  if (values.image) {
    report.image = { reference: values.image, platform: values.platform, status: 'failed' };
    if (!/^[a-z0-9][a-z0-9./:_-]*@sha256:[a-f0-9]{64}$/i.test(values.image)) {
      report.image.message = 'Use a registry image reference with a sha256 digest.';
    } else {
      const scan = spawnSync('syft', [
        'scan', 'registry:' + values.image, '--platform', values.platform, '-o', 'cyclonedx-json',
      ], { encoding: 'utf8', maxBuffer: 128 * 1024 * 1024, timeout: 120_000, windowsHide: true });
      if (scan.error || scan.status !== 0) report.image.message = scan.error?.message ?? 'Syft returned a nonzero exit code.';
      else {
        write(out, 'image.sbom.cdx.json', JSON.parse(scan.stdout));
        report.image.status = 'inventoried';
      }
    }
  }
  write(out, 'report.json', report);
  console.log(result.status + ' · ' + result.name + ' · ' + out);
  if (result.status !== 'resolved' || report.image?.status === 'failed') process.exitCode = 2;
}

main().catch(error => {
  console.error(error.message);
  process.exitCode = 1;
});
