import Ajv from 'ajv';
import { readFileSync } from 'node:fs';
import { validateGraph } from './collect.mjs';

const readSchema = name => JSON.parse(readFileSync(new URL('../schema/' + name, import.meta.url)));
const ajv = new Ajv({ strict: false, validateFormats: false, allErrors: true });
ajv.addSchema(readSchema('spdx.schema.json'), 'http://cyclonedx.org/schema/spdx.schema.json');
ajv.addSchema(readSchema('jsf-0.82.schema.json'), 'http://cyclonedx.org/schema/jsf-0.82.schema.json');
const validate = ajv.compile(readSchema('bom-1.6.schema.json'));

export function validateSbom(bom) {
  if (!validate(bom)) throw new Error('CycloneDX schema validation failed: ' + ajv.errorsText(validate.errors));
}

export function exportSbom(graph, source) {
  validateGraph(graph);
  const component = node => ({
    type: node.id === graph.rootId ? 'application' : 'library',
    'bom-ref': node.id,
    name: node.name,
    ...(node.version ? { version: node.version } : {}),
    ...(node.purl ? { purl: node.purl } : {}),
  });
  const byId = new Map(graph.nodes.map(node => [node.id, component(node)]));
  const children = new Map(graph.nodes.map(node => [node.id, new Set()]));
  for (const edge of graph.edges) children.get(edge.from).add(edge.to);

  const bom = {
    bomFormat: 'CycloneDX', specVersion: '1.6', version: 1,
    metadata: {
      component: byId.get(graph.rootId),
      properties: [
        { name: 'guardian:source:commit', value: source.commit },
        { name: 'guardian:source:app', value: source.app },
        { name: 'guardian:source:lockfile', value: source.lockfile },
      ],
    },
    components: [...byId.values()].filter(item => item['bom-ref'] !== graph.rootId),
    dependencies: [...children].map(([ref, targets]) => ({ ref, dependsOn: [...targets].sort() })),
  };
  validateSbom(bom);
  verifyRelationships(graph, bom);
  return bom;
}

export function verifyRelationships(graph, bom) {
  const key = (from, to) => JSON.stringify([from, to]);
  const expected = new Set(graph.edges.map(edge => key(edge.from, edge.to)));
  const exported = new Set(bom.dependencies.flatMap(row => row.dependsOn.map(to => key(row.ref, to))));
  const ids = graph.nodes.map(node => node.id).sort();
  const bomRefs = [bom.metadata.component['bom-ref'], ...bom.components.map(item => item['bom-ref'])].sort();
  const dependencyRefs = bom.dependencies.map(item => item.ref).sort();
  if (expected.size !== exported.size || [...expected].some(edge => !exported.has(edge)) ||
      bom.metadata.component['bom-ref'] !== graph.rootId ||
      JSON.stringify(ids) !== JSON.stringify(bomRefs) || JSON.stringify(ids) !== JSON.stringify(dependencyRefs)) {
    throw new Error('CycloneDX component or edge references differ from the graph.');
  }
}
