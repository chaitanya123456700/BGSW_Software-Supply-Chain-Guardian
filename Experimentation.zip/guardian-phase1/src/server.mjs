import { createServer } from 'node:http';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { parseArgs } from 'node:util';
import { Worker } from 'node:worker_threads';
import { parseRepository } from './github.mjs';
import { renderViewer } from './render-viewer.mjs';

const { values } = parseArgs({ options: { port: { type: 'string', default: '4173' } } });
if (!/^\d+$/.test(values.port) || Number(values.port) > 65535) throw new Error('Use --port with a number from 0 to 65535.');
const host = '127.0.0.1';
const demos = JSON.parse(readFileSync(new URL('../demos.json', import.meta.url)));
const html = renderViewer({ mode: 'live', demos });
const workspace = mkdtempSync(path.join(tmpdir(), 'guardian-web-'));
const sessions = new Map();
const sessionLimit = 4;
const sessionLifetime = 30 * 60 * 1000;
let activeJobs = 0;

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function pruneSessions(limit = sessionLimit) {
  for (const [id, entry] of sessions) {
    if (!entry.active && (sessions.size > limit || Date.now() - entry.touched > sessionLifetime)) {
      sessions.delete(id);
      rmSync(entry.directory, { recursive: true, force: true });
    }
  }
}

function runWorker(input) {
  return new Promise((resolve, reject) => {
    const worker = new Worker(new URL('./web-scan.mjs', import.meta.url), {
      workerData: input,
      env: { ...process.env, GIT_NO_LAZY_FETCH: '1' },
      resourceLimits: { maxOldGenerationSizeMb: 384 },
    });
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      void worker.terminate();
    }, 120_000);
    worker.once('message', result => { if (!timedOut) resolve(result); });
    worker.once('error', () => {
      if (!timedOut) reject(new HttpError(422, 'The scan exceeded its processing limits or could not read the repository.'));
    });
    worker.once('exit', () => {
      clearTimeout(timer);
      reject(timedOut
        ? new HttpError(504, 'The scan timed out. Try again or use a smaller repository.')
        : new HttpError(422, 'The scan ended before producing a result.'));
    });
  });
}

async function readInput(request) {
  if (request.headers['content-type']?.split(';')[0] !== 'application/json') {
    request.resume();
    throw new HttpError(415, 'Send a JSON request.');
  }
  const chunks = [];
  let size = 0;
  for await (const chunk of request.iterator({ destroyOnReturn: false })) {
    size += chunk.length;
    if (size > 8192) {
      request.resume();
      throw new HttpError(413, 'Scan request is too large.');
    }
    chunks.push(chunk);
  }
  let data;
  try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch {}
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new HttpError(400, 'Invalid scan request.');
  return data;
}

function json(response, status, data) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  response.end(JSON.stringify(data));
}

async function scan(input) {
  let target;
  let entry;
  if (input.session !== undefined) {
    entry = sessions.get(input.session);
    if (!entry || (Date.now() - entry.touched > sessionLifetime && !entry.active)) {
      throw new HttpError(410, 'This scan session expired. Submit the repository URL again.');
    }
    if (!entry.apps.includes(input.app)) throw new HttpError(400, 'Choose an app from the discovered paths.');
    target = entry.target;
  } else {
    try { target = parseRepository(input.url); }
    catch (error) { throw new HttpError(400, error.message); }
  }
  if (activeJobs >= 2) throw new HttpError(429, 'Two scans are running. Try again when one finishes.');
  activeJobs++;
  let directory;
  let keep = false;
  try {
    if (entry) {
      entry.active++;
      entry.touched = Date.now();
      sessions.delete(input.session);
      sessions.set(input.session, entry);
      const { result } = await runWorker({ directory: entry.directory, target, commit: entry.commit, app: input.app });
      return { session: input.session, apps: entry.apps, result };
    }

    pruneSessions(sessionLimit - 1);
    directory = mkdtempSync(path.join(workspace, 'repo-'));
    const { apps, commit, result, error } = await runWorker({ directory, target, requestedApp: input.app });
    if (error) throw new HttpError(422, error);
    const session = randomUUID();
    sessions.set(session, { apps, commit, target, directory, touched: Date.now(), active: 0 });
    keep = true;
    return { session, apps, result };
  } finally {
    if (entry) entry.active--;
    if (directory && !keep) rmSync(directory, { recursive: true, force: true });
    activeJobs--;
    pruneSessions();
  }
}

const server = createServer(async (request, response) => {
  const authority = host + ':' + server.address().port;
  if (request.headers.host !== authority || (request.headers.origin && request.headers.origin !== 'http://' + authority)) {
    json(response, 403, { error: 'Open Guardian using the local URL printed in your terminal.' });
    return;
  }
  const route = request.url.split('?')[0];
  if (request.method === 'GET' && route === '/') {
    response.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store',
      'Referrer-Policy': 'no-referrer',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src data:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
    });
    response.end(html);
    return;
  }
  if (request.method === 'POST' && route === '/api/scan') {
    try { json(response, 200, await scan(await readInput(request))); }
    catch (error) {
      if (!error.status) console.error(error.message);
      json(response, error.status ?? 500, { error: error.status ? error.message : 'Guardian could not complete the scan.' });
    }
    return;
  }
  json(response, 404, { error: 'Page not found.' });
});

const cleanup = setInterval(pruneSessions, 60_000);
cleanup.unref();
process.on('exit', () => rmSync(workspace, { recursive: true, force: true }));
for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => server.close(() => process.exit()));
server.on('error', error => {
  console.error(error.code === 'EADDRINUSE' ? 'Guardian port is in use. Try npm start -- --port 4174.' : error.message);
  process.exitCode = 1;
});
server.listen(Number(values.port), host, () => console.log('Supply Chain Guardian is ready at http://' + host + ':' + server.address().port));
