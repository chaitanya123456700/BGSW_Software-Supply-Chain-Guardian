import { execFileSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';

const metadata = /(^|\/)(package\.json|package-lock\.json|npm-shrinkwrap\.json|pnpm-lock\.yaml|yarn\.lock|bun\.lockb?)$/;

export function git(repo, ...args) {
  return execFileSync('git', ['-C', repo, ...args], {
    maxBuffer: 128 * 1024 * 1024,
    windowsHide: true,
    env: { ...process.env, GIT_NO_REPLACE_OBJECTS: '1' },
  });
}

export function appPath(input) {
  const dir = path.posix.normalize(input.replaceAll('\\', '/')).replace(/\/$/, '');
  if (path.posix.isAbsolute(dir) || dir === '..' || dir.startsWith('../') || dir.includes(':') ||
      dir.split('/').some(part => /^\.git[. ]*$/i.test(part) || /[\u0000-\u001f]/.test(part))) {
    throw new Error('Select an application path relative to the repository.');
  }
  return dir || '.';
}

export function metadataEntries(repo, commit) {
  const entries = git(repo, 'ls-tree', '-r', '-z', '--full-tree', commit).toString().split('\0');
  const requestedBlobs = [];
  for (const entry of entries) {
    const separator = entry.indexOf('\t');
    if (separator < 0) continue;
    const file = entry.slice(separator + 1);
    const [mode, type, hash] = entry.slice(0, separator).split(' ');
    if (type !== 'blob' || !['100644', '100755'].includes(mode) || !metadata.test(file)) continue;
    if (file.split('/').includes('node_modules') || file.includes('\\')) continue;
    try {
      if (appPath(file) !== file) continue;
    } catch {
      continue;
    }
    requestedBlobs.push([file, hash]);
  }
  return requestedBlobs;
}

export function extractSnapshot(repo, ref) {
  const commit = git(repo, 'rev-parse', '--verify', '--end-of-options', ref + '^{commit}').toString().trim();
  const files = new Map();
  const requestedBlobs = metadataEntries(repo, commit);
  if (requestedBlobs.length) {
    const blobs = execFileSync('git', ['-C', repo, 'cat-file', '--batch'], {
      input: requestedBlobs.map(([, hash]) => hash).join('\n') + '\n',
      maxBuffer: 128 * 1024 * 1024,
      windowsHide: true,
      env: { ...process.env, GIT_NO_REPLACE_OBJECTS: '1' },
    });
    let offset = 0;
    for (const [file, hash] of requestedBlobs) {
      const headerEnd = blobs.indexOf(10, offset);
      const [actual, type, rawSize] = blobs.toString('ascii', offset, headerEnd).split(' ');
      const size = Number(rawSize);
      if (headerEnd < 0 || actual !== hash || type !== 'blob' || !Number.isSafeInteger(size)) {
        throw new Error('Could not read metadata from the pinned commit.');
      }
      offset = headerEnd + 1;
      files.set(file, blobs.subarray(offset, offset + size));
      offset += size + 1;
    }
  }

  const directory = mkdtempSync(path.join(tmpdir(), 'guardian-'));
  try {
    for (const [file, bytes] of files) {
      if (file.endsWith('/package.json') || file === 'package.json') {
        const target = path.join(directory, file);
        mkdirSync(path.dirname(target), { recursive: true });
        writeFileSync(target, bytes);
      }
    }
  } catch (error) {
    rmSync(directory, { recursive: true, force: true });
    throw error;
  }

  return { directory, commit, files, close: () => rmSync(directory, { recursive: true, force: true }) };
}
